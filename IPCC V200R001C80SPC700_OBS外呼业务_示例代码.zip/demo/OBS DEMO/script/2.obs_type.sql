/******************************************************************************/
/*                                                                            */
/*                            OBS相关类型                                      */
/*                                                                            */
/******************************************************************************/
CREATE OR REPLACE TYPE TP_HPS_DATARESULTRECORD IS OBJECT(
    SERVICEID   VARCHAR2(30),
    UNIQUEID    VARCHAR2(20),
    PHONENUMBER VARCHAR2(120),
    CALLDATA    VARCHAR2(1024)
)
/

CREATE OR REPLACE TYPE TP_HPS_DATARESULT IS TABLE OF TP_HPS_DATARESULTRECORD
/