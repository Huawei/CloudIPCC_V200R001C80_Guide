﻿//AgentUIClass constructor
function AgentUIClass() {
}

//AgentUIClass methods define
AgentUIClass.prototype = {
    UpdateCallStatus: function () {
        var ret = AgentState.GetCallInfo();

        if (ret === 0) {
            var calltype = "";
            var calleeNo = AgentState.GetCalleeNo();
			var calledNo = AgentState.GetCalledNo();
            var callFeature = AgentState.GetCallFeature();

            if (callFeature === 0) {
                calltype = "Inbound";
            }
            else if (callFeature === 6) {
                calltype = "Internal";
            }
            else if (callFeature === 7) {
                calltype = "Outbound";
            }
            else if (callFeature === 51) {
                calltype = "2-Party-Help";
            }
            else if (callFeature === 52) {
                calltype = "3-Party-Help";
            }
			var holdTipString = "";
			if (AgentState.GetHoldFlag() === 1){
				holdTipString = "<font color=red>" +'Hold' +"</font>";
			}
			document.getElementById("AgentAppDemo.CallStatus").innerHTML = "<font color=blue>" + calleeNo + " | " + calltype + '|' + calledNo + "</font>" + holdTipString;
        }
        else {
            document.getElementById("AgentAppDemo.CallStatus").innerHTML = "<font color=red>No Calls</font>";
        }
    },
    UpdateAgentStatus: function (usAgentID) {
        var ret = 0;
        var curState = 0;
        var agentStatus = "Not Login";
        var color = "red";
        var self = "I18N_STATUS_LOGOUT";

        ret = AgentOcx._ocx.QueryAgentStatusEx(usAgentID);

        if (ret === 0) {
            curState = AgentOcx._ocx.AgentInfoEx_CurState;

            if (curState === 0) {
                agentStatus = "Not Login";
                color = "red";
                self = "I18N_STATUS_LOGOUT";
            }
            else if (curState === 1) {
                agentStatus = "Idle";
                color = "green";
                self = "I18N_STATUS_IDLE";
            }
            else if (curState === 2) {
                agentStatus = "PreOccupy";
                color = "blue";
                self = "I18N_STATUS_PREOCCUPY";
            }
            else if (curState === 3) {
                agentStatus = "Occupy";
                color = "blue";
                self = "I18N_STATUS_OCCUPY";

            }
            else if (curState === 4) {
                agentStatus = "Alerting";
                color = "blue";
                self = "I18N_STATUS_ALERT";
            }
            else if (curState === 5) {
                agentStatus = "Talking";
                color = "blue";
                self = "I18N_STATUS_TALK";
            }
            else if (curState === 6) {
                agentStatus = "Working";
                color = "blue";
                self = "I18N_STATUS_WORK";

            }
            else if (curState === 7) {
                agentStatus = "Busy";
                color = "blue";
                self = "I18N_STATUS_BUSY";

            }
            else if (curState === 8) {
                agentStatus = "Resting";
                color = "blue";
                self = "I18N_STATUS_REST";
            }
            else if (curState === 9) {
                agentStatus = "Studying";
                color = "blue";
                self = "I18N_STATUS_STUDY";
            }
            else if (curState === 10) {
                agentStatus = "WorkAdjust";
                color = "blue";
                self = "I18N_STATUS_WORKADJ";
            }
        }

        document.getElementById("AgentAppDemo.AgentStatus").innerHTML = "<span style='color:" + color + "' self='" + self + "'>" + agentStatus + "</font>";
    },
    UpdateWhenPrepareJoinMultimediaConf: function (sConfInfo) {
        //automatically fire the action to join conf
        ConferenceExcute("JoinConf", sConfInfo);
    },
    UpdateChatContent: function (ccbIdx) {
        var chatcontent = AgentState.GetAgentChatContent(ccbIdx);
		if (chatcontent === null || chatcontent === undefined)
		{
			chatcontent = "";
		}
        document.getElementById("AgentAppDemo.RecvContent").value = chatcontent;
    },
    SelectChat: function (ccbIdx) {
        if (document.getElementById("chat_sel_" + AgentState.GetChatCCBIdx())) {
            document.getElementById("chat_sel_" + AgentState.GetChatCCBIdx()).style.color = "blue";
        }
        // cancel highlight to tell the agent to notice
        document.getElementById("chat_ccb_" + ccbIdx).style.background = "white";
        var chatcontent = AgentState.GetAgentChatContent(ccbIdx);
		if (chatcontent === null)
		{
			chatcontent = "";
		}
        document.getElementById("AgentAppDemo.RecvContent").value = chatcontent;
        //selected the ccbidx's chat
        AgentState.SetChatCCBIdx(ccbIdx);
        if (document.getElementById("chat_sel_" + AgentState.GetChatCCBIdx())) {
            document.getElementById("chat_sel_" + AgentState.GetChatCCBIdx()).style.color = "#FF00FF";
        }
    },
	UpdateWhenChatReleased: function(ccbIdx){ 
		AgentState.ClearAgentChatContent(ccbIdx);
        //if current talking , imediately update chat content
        if (AgentState.GetChatCCBIdx() === ccbIdx) {
            this.UpdateChatContent(ccbIdx);
        }
        //delete the content
        var elem = document.getElementById('chat_ccb_' + ccbIdx);
        if (elem) {
            elem.parentNode.removeChild(elem);
        }
	},
    DelChat: function (ccbIdx) {
        //release the call
        AgentExcute("ReleaseCallEx", 1, ccbIdx);
        AgentState.ClearAgentChatContent(ccbIdx);
        //if current talking , imediately update chat content
        if (AgentState.GetChatCCBIdx() === ccbIdx) {
            this.UpdateChatContent(ccbIdx);
        }
        //delete the content
        var elem = document.getElementById('chat_ccb_' + ccbIdx);
        if (elem) {
            elem.parentNode.removeChild(elem);
        }
    },
    UpdateWhenSendChatMessage: function (ccbIdx) {
        //if there the call exists
        if (document.getElementById("chat_ccb_" + ccbIdx)) {
            //if current talking , imediately update chat content
            if (AgentState.GetChatCCBIdx() === ccbIdx) {
                this.UpdateChatContent(ccbIdx);
				document.getElementById("AgentAppDemo.SendContent").value = '';
            }
        }
        else {
            alert("Error, send chat message, but ressponding ccblist not exists!The webchat call has not be connected");
            return;
        }
    },
    UpdateWhenReceiveChatMessage: function (ccbIdx) {
        //if there the call exists
        if (document.getElementById("chat_ccb_" + ccbIdx)) {
            // highlight to tell the agent to notice
            document.getElementById("chat_ccb_" + ccbIdx).style.background = "#BBE0E3";
            //if current talking , imediately update chat content
            if (AgentState.GetChatCCBIdx() === ccbIdx) {
                this.UpdateChatContent(ccbIdx);
            }
        }
        else {
            alert("Error, receive chat message, but ressponding ccblist not exists!");
            return;
        }
    },
    UpdateWhenChatAnswered: function (ccbIdx) {
        var ccbDiv = "<div  id='" + "chat_ccb_" + ccbIdx + "' style='height:30px; line-height:30px; text-align:center;'>" +
            "<a style='color:blue' href='javascript:AgentUI.SelectChat(" + ccbIdx + ")' id='chat_sel_" + ccbIdx + "'> chat_ccb_" + ccbIdx + "</a>" +
            "<a style='color:blue' href='javascript:AgentUI.DelChat(" + ccbIdx + ")'> Release </a>" + "</div>";
        document.getElementById("AgentAppDemo.ChatCCBList").innerHTML += ccbDiv;
        // highlight to tell the agent to notice
        document.getElementById("chat_ccb_" + ccbIdx).style.background = "#BBE0E3";
    },
    UpdateWhenChatEnded: function (ccbIdx) {
        AgentState.ClearAgentChatContent(ccbIdx);
        //delete the content
        var elem = document.getElementById('chat_ccb_' + ccbIdx);
        if (elem) {
            elem.parentNode.removeChild(elem);
        }
    }
}