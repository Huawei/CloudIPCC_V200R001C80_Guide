﻿// Userapp demo
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var UserAppDemo = function()
{
    this.CreateVideoDeviceWindow = function (userId, deviceId) {
        //create window
        var hwndInfo = WndUiExcute('Create', 'Video_' + userId + '_' + deviceId);
        var obj = JSON.parse(hwndInfo);
        //start draw the video
        ConferenceExcute('StartDrawVideo', userId, deviceId, obj.hWnd, 1); //mode 1 indicates that it draws the video by ratio
        WndUiUI.UpdateWindowList();
        return '';
    }
    this.CloseVideoDeviceWindow = function (userId, deviceId, hWnd) {
        //stop draw the video
        ConferenceExcute('StopDrawVideo', userId, deviceId, hWnd);
        //destroy the window
        WndUiExcute("Destroy", hWnd);
        WndUiUI.UpdateWindowList();
        return "";
    }
    this.CreateDesktopShareWindow = function () {
        // create windows
        var hwndInfo = WndUiExcute("Create", 'DesktopShare Window');
        var obj = JSON.parse(hwndInfo);
        ConferenceState.SetDesktopShareHwnd(obj.hWnd);
        //set desktop share display window
        ConferenceExcute('SetDisplayShareScreenWnd', ConferenceState.GetDesktopShareHwnd());
        WndUiUI.UpdateWindowList();
        return '';
    }

    this.OpenDialog = function (dialogName, arguments, width, height) {
        var arg = arguments;
		if (arg === null || arg === undefined){
			INFO_LOG_METHOD("UserAppDemo","someting go wrong here, the arg is null");
			return;
		}
        arg.dialog = dialogName;
		arg.Config = UserConfig;
        dialogRet = window.showModalDialog("scripts/demo/common/dialog.html", arg, "dialogWidth=" + width + "px;dialogHeight=" + height + "px;status=yes;scroll=no;help=no;");
        return dialogRet;
    }

    this.ChooseConfMemberUser = function (tipmessage) {
        var arg = new Object();
        arg.memberList = ConferenceState.GetConfMemberList();
        arg.tipmessage = tipmessage;
        var userid = UserAppDemoExcute("OpenDialog", "ChooseConfMember", arg, 400, 300);
        //if not correct selected, return null
        if (typeof userid === "undefined") {
            return null;
        }
        return userid;
    }

    this.ChooseLocalVideoDevice = function () {
        var arg = new Object();
        arg.deviceList = ConferenceState.GetLocalDeviceList();
        arg.tipmessage = "I18N_DIALOG_TIPMESSAGE_CHOOSE_LOCAL_VIDEO";
        var deviceid = UserAppDemoExcute("OpenDialog", "ChooseLocalVideoDevice", arg, 600, 300);
        //if not correct selected, return null
        if (typeof deviceid === "undefined") {
            return null;
        }
        return deviceid;
    }
    this.ChooseVideoParam = function(){
        var arg = new Object();
        var paramInfo = ConferenceExcute("GetSupportVideoParams", UserState.GetSelectedVideoDevice());
        var obj = JSON.parse(paramInfo);
        if (obj.resultCode != 0)
        {
            Alert("Get Support Video Param Failed");
            return;
        }
        var paramList = [];
        for (var i=0; i < obj.supportVideoParam.length; i++)
        {
            paramList.push(JSON.stringify(obj.supportVideoParam[i]));
        }
        arg.paramList = paramList;
        arg.tipmessage = "Set video param";
        var param = UserAppDemoExcute("OpenDialog", "ChooseVideoParam", arg, 600, 400);
        //if not correct selected, return null
        if (typeof param === "undefined") {
            return null;
        }
        return param;
    }
    this.GetCallbackPhoneNumber = function () {
        var arg = new Object();
        arg.tipmessage = "I18N_DIALOG_TIPMESSAGE_GETCALLBACK_PHONENUMBER";
        var phoneNumber = UserAppDemoExcute("OpenDialog", "GetCallbackPhoneNumber", arg, 400, 100);
        //if not correct selected, return null
        if (typeof phoneNumber === "undefined") {
            return null;
        }
        return phoneNumber;
    }
    this.CallAnonymousCallee = function () {
        VoiceExcute("AnonymousCall", UserConfig.Voice.AnnonymousCard, ICSClientState.GetCurrentAnonymousCallee()); // auto call
    }
    this.ReportJoinMeetingResult = function (success, resultCode) {
        ICSClientExcute("ReportJoinMeetingResult", ConferenceState.GetCurrentJoinedConfID(), success, resultCode); // report if the user has joined the conference to CTI 
    }
    this.ReportMeetingTeminated = function () {
        return ICSClientExcute('TerminateMeeting', ConferenceState.GetCurrentJoinedConfID());
    }
    this.QueryErrorCode = function (ocx, errCode) {
        if (ocx === 'ConferenceOcx') {
            return ConferenceExcute("GetResultDesc", errCode);
        }
        else if (ocx === 'VoiceOcx') {
            return VoiceExcute("GetResultDesc", errCode);
        }
        else if (ocx === 'ICSClientOcx') {
            return ICSClientExcute("GetResultDesc", errCode);
        }
    }
}

UserAppDemo.prototype =
{
    //begin: interface for the html to invoke
    Login: function (userName) {
        //1、login icsgateway
        return ICSClientExcute("Login", userName);
    },
    Logout: function () {
        //if the meeting still existes, terminate it
        if (ConferenceState.GetCurrentJoinedConfID() !== '') {
            ConferenceExcute("TerminateConf");
        }
        // check if the call exists,otherwise release it
        if (ICSClientState.GetWebChatCallState().callID !== '') {
            ICSClientExcute("Release", ICSClientState.GetWebChatCallState().callID);
        }
        // check if the call exists,otherwise release it
        if (ICSClientState.GetClickCallCallState().callID !== '') {
            ICSClientExcute("Release", ICSClientState.GetClickCallCallState().callID);
        }
        // check if the call exists,otherwise release its
        if (ICSClientState.GetCallBackCallState().callID !== '') {
            ICSClientExcute("Release", ICSClientState.GetCallBackCallState().callID);
        }
        return ICSClientExcute("Logout");
    },
    UpdateVerifyCode: function(verifyCode) {
        return ICSClientExcute("UpdateVerifyCode", verifyCode);
    },
    GetVerifyCode: function(imgId) {
        return ICSClientExcute("GetVerifyCode", imgId);
    },
    Call: function (mediaType, accessCode, calldata) {
		if (ICSClientState.HasTalkOfCallType(ICSCLIENT_USER_CALLTYPE.ICSCLIENT_USER_CALLTYPE_VCCALL))
		{
			if (mediaType === "4")//4 indicates that this is a callback call
			{
				var phoneNumber = UserAppDemoExcute("GetCallbackPhoneNumber");
				if (phoneNumber === null) {
					return 'ERROR: operation not correctly, Phone Number not filled ';
				}
				if (phoneNumber < 0) {
					return 'ERROR: operation not correctly, Phone Number should not be less than 0 ';
				}
				var callInfo =  ICSClientExcute("Call", mediaType, accessCode, phoneNumber, -1);
				var obj = JSON.parse(callInfo);
				if (parseInt(obj.retcode) === 0){
					ICSClientState.AlertCallBack(obj.result);
				}
				return callInfo;
			}
			else if (mediaType === "22")//22 indicates that this is a vc call, end vccall should not use compabitible call
			{
				var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, -1);
				var obj = JSON.parse(callInfo);
				if (parseInt(obj.retcode) === 0){
					ICSClientState.AlertVCCall(obj.result);
				}
				return callInfo;
			}
			else if (mediaType === "2")
			{
				var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, -1);
				var obj = JSON.parse(callInfo);
				if (parseInt(obj.retcode) === 0){
					ICSClientState.AlertClickCall(obj.result);
				}
				return callInfo;
			}
			else if (mediaType === "1"){
				var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, -1);
				var obj = JSON.parse(callInfo);
				if (parseInt(obj.retcode) === 0){
					ICSClientState.AlertWebChat(obj.result);
				}
				return callInfo;
			}
		}
		
        if (mediaType === "4")//4 indicates that this is a callback call
        {
            var phoneNumber = UserAppDemoExcute("GetCallbackPhoneNumber");
            if (phoneNumber === null) {
                return 'ERROR: operation not correctly, Phone Number not filled ';
            }
            if (phoneNumber < 0) {
                return 'ERROR: operation not correctly, Phone Number should not be less than 0 ';
            }
			var callInfo =  ICSClientExcute("Call", mediaType, accessCode, phoneNumber, ICSClientState.GetCurrentCallUVID());
			var obj = JSON.parse(callInfo);
			if (parseInt(obj.retcode) === 0){
				ICSClientState.AlertCallBack(obj.result);
			}
			return callInfo;
        }
		else if (mediaType === "22")//22 indicates that this is a vc call, end vccall should not use compabitible call
        {
			var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, -1);
			var obj = JSON.parse(callInfo);
			if (parseInt(obj.retcode) === 0){
				ICSClientState.AlertVCCall(obj.result);
			}
			return callInfo;
        }
		else if (mediaType === "2")
		{
			var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, ICSClientState.GetCurrentCallUVID());
			var obj = JSON.parse(callInfo);
			if (parseInt(obj.retcode) === 0){
				ICSClientState.AlertClickCall(obj.result);
			}
			return callInfo;
		}
        else if (mediaType === "1"){
			var callInfo =  ICSClientExcute("Call", mediaType, accessCode, calldata, ICSClientState.GetCurrentCallUVID());
			var obj = JSON.parse(callInfo);
			if (parseInt(obj.retcode) === 0){
				ICSClientState.AlertWebChat(obj.result);
			}
			return callInfo;
        }
    },
    Release: function (mediaType) {
		//first if it is voice call ,release the phone call
		if (parseInt(mediaType) === 2)//if it is voice call
		{
			VoiceExcute("Release","");
		}
        if (ConferenceState.GetCurrentJoinedConfID() !== '') { // if there is conf , release it
            ConferenceExcute("TerminateConf");
        }
        if (ICSClientState.GetCurrentCallID() === "") {
            return "ERROR: mediaType -" + mediaType + " does not have corresponding call, please call first";
        }
		//the follow code is to release the alerting call, end of alerting call will not cause an event to update status, so update it here
        return ICSClientExcute("Release", ICSClientState.GetCurrentCallID());
    },
    CancelQueue: function (mediaType) {
        if (ICSClientState.GetCurrentCallID() === "") {
            return "ERROR: mediaType -" + mediaType + " does not have corresponding call queueing, please call first";
        }
        return ICSClientExcute("CancelQueue", ICSClientState.GetCurrentCallID());
    },
    CreateMeeting: function () {
        if (ICSClientState.GetCurrentCallID() === "") {
            return "ERROR: There is no call, please call first before you create meeting";
        }
        return ICSClientExcute("RequestMeeting", ICSClientState.GetCurrentCallID());
    },
    ReleaseMeeting: function () {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: There is no meeting to release.';
        }
        return ConferenceExcute("TerminateConf");
    },
    ShowWindow: function (hwnd, width, height) {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
		if (!UTIL.CheckIsNumber(width) || !UTIL.CheckIsNumber(height)){
			return 'ERROR: width or height input error';
		}
		if (width <= 0 || height <= 0){
			return 'ERROR: width or height <= 0';
		}
        var wndList = WndUiState.GetWndList();
		var title = "";
        for (var i = 0; i < wndList.length; i++) {
            if (wndList[i].hwnd === parseInt(hwnd)) {
				title = wndList[i].title;
                break;
            }
        }
		//if try to show a desktopshare window
		if (title.indexOf("DesktopShare") >= 0){
			
			var changedHeight = width*(ConferenceState.GetDesktopShareDisplaySet().y/ConferenceState.GetDesktopShareDisplaySet().x);
			ConferenceExcute("SetShareScreenDisplaySize", parseInt(width), parseInt(changedHeight));
			return WndUiExcute('Show', hwnd, parseInt(width)+15, parseInt(changedHeight) + 35);//add 2 for the border width of the window,add 27 for the border height of the window
		}
		else{
			return WndUiExcute('Show', hwnd, parseInt(width), parseInt(height));
		}
    },
    OpenLocalVideo: function () {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        var deviceid = UserAppDemoExcute("ChooseLocalVideoDevice");
        if (deviceid === null) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        if (deviceid <= 0) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        UserState.SetSelectedVideoDevice(deviceid);
        return ConferenceExcute('OpenVideoDevice', deviceid);
    },
	
    SetVideoParam: function(){
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        var param = UserAppDemoExcute("ChooseVideoParam");
        if (param == null) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        if (param == undefined) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        // first close it
        ConferenceExcute("CloseVideoDevice", UserState.GetSelectedVideoDevice());
        var setParamExcute = "ConferenceExcute('SetVideoCurrentParam',"+ UserState.GetSelectedVideoDevice() + ",\'"+ param + "\')";
        var t1 = setTimeout(setParamExcute,1500)
        //ConferenceExcute('SetVideoCurrentParam', UserState.GetSelectedVideoDevice(), param);
        var t2 = setTimeout(" ConferenceExcute('OpenVideoDevice',"+ " " + UserState.GetSelectedVideoDevice()+ ")",2000);
        //ConferenceExcute("OpenVideoDevice", UserState.GetSelectedVideoDevice());
    },
    CloseLocalVideo: function () {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        if (UserState.GetIsLocalVideoOpened())
        {
            return ConferenceExcute('CloseVideoDevice', UserState.GetSelectedVideoDevice());
        }
		else
		{
			INFO_LOT_METHOD("UserAppDemo","Video deivice not opened");
		}
        return ConferenceExcute('CloseVideoDevice', deviceid);
    },
    StartDesktopShare: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        //share desktop share
        return ConferenceExcute('StartShareScreen', 'desktop');

    },
    StopDesktopShare: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        //stop desktop share
        return ConferenceExcute('StopShareScreen');
    },
    AllowRemoteCtrl: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        var userid = UserAppDemoExcute("ChooseConfMemberUser", "I18N_DIALOG_TIPMESSAGE_ALLOW_REMOTE_CTRL");
        if (userid === null) {
            return 'ERROR: operation not correctly, conf member not chosen';
        }
        if (ConferenceState.IsSelfUser(userid)) {
            return 'ERROR: can not set yourself the remotectrl privileage';
        }
        if (!ConferenceState.IsInConfMemberList(userid)) {
            return 'ERROR: userid:' + userid + " not in the meeting now";
        }

        return ConferenceExcute('SetOperationPrivilege', userid, 'remotectl', 'add');
    },
    StopRemoteCtrl: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
		
        return ConferenceExcute('SetOperationPrivilege', ConferenceState.GetDesktopShareControlUser(), 'remotectl', 'delete'); //stop the currentTalking user to control
    },
    SendChatMessage: function (content) {
        if (ICSClientState.GetWebChatCallState().callID === "") {
            return 'Error: Webchat call did not exists, please call first';
        }
        //execute the sendTextMsg method and get the result
        var resultInfo = ICSClientExcute('SendTextMsg', ICSClientState.GetWebChatCallState().callID, content);
        var obj = JSON.parse(resultInfo);
        // if sent failed , tip the user by add failed information 
        if (obj.retcode !== "0") {
            content = "<failed>" + content;
        }
        ICSClientState.SendChatContent('Self', decodeURI(content) );
        return resultInfo;
    },
    ClearChatHistory: function () {
        ICSClientState.ClearChatContent();
        return '';
    },
    SendFile: function (sendfile) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        var userid = UserAppDemoExcute("ChooseConfMemberUser", "I18N_DIALOG_TIPMESSAGE_SENDFILE");
        if (userid === null) {
            return 'ERROR: operation not correctly, conf member not chosen';
        }
        if (ConferenceState.IsSelfUser(userid)) {
            return 'ERROR: can not send file to yourself';
        }
        if (!ConferenceState.IsInConfMemberList(userid)) {
            return 'ERROR: userid:' + userid + " not in the meeting now";
        }
        return ConferenceExcute('SendFile', userid, sendfile);
    },
    CancelSendFile: function (filehandle) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        return ConferenceExcute('CancelSendingFile', filehandle);
    },
    ReceiveFile: function (fileHandle, savefile) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        return ConferenceExcute('ReceiveFile', fileHandle, savefile);
    },
    CancelReceive: function (fileHandle) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        return ConferenceExcute('CancelReceiveFile', fileHandle);
    }


}

