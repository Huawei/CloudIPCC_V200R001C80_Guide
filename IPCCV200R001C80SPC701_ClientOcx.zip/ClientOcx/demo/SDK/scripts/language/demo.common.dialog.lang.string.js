﻿// language string definition file
// Copyright Huawei Technologies Co., Ltd. 2016. All rights reserved.
/*
 * this file defines the language strings of diference language , 
 * the LangugePageClass has a public interface GetLanguagePage which returns the language string define page of specified language for self attributed  element. 
 *
 * Notice:
 * To Add a new language you need to as following
 * 1. In the LANGUGE_SUPPORT object , add a new member like LANGUAGE_SUPPORT_XXX:"XXX", NOTE That the javascript object members sperated by ","
 * 2. Copy the Language.English object definition, changes to Languge.XXX . Modify the member value to the string of specified string for language XXX
 * 3. In the GetLanguagePage method of LanguagePageClass, add an else if branch which enables the function to return the languagepage of specified language xxx.
 * 4. Done.
 */
//language supported  
LANGUAGE_SUPPORT = {
	LANGUAGE_SUPPORT_CHINESE:"Chinese",
	LANGUAGE_SUPPORT_ENGLISH:"English"
}

//LanguagePageClass
function LanguagePageClass()
{
	// function
	// desc: the function reture the language string define page for specified language
	// params：
	// [IN] lan : string of language
	// return： void
	this.GetLanguagePage = function(language){
		if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_CHINESE){
			return LanguageString.Chinese;
		}
		else if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_ENGLISH){
			return LanguageString.English;
		}
		else{
			return LanguageString.English;
		}
	}
}

var LanguageString = {};
LanguageString.Chinese = {
	I18N_DIALOG_ConferenceMemberList:"会议成员列表",
    I18N_DIALOG_CurrentSelectedUser:"当前选中的用户",
    I18N_DIALOG_LOCAL_VIDEO_DEVICE_LIST:"本地视频设备列表",
    I18N_DIALOG_VIDEO_DEVICE_SELECTED:"当前选中的设备",
    I18N_DIALOG_CALLBACK_PHONENUMBER:"回呼电话号码",
	I18N_DIALOG_TIPMESSAGE_CHOOSE_LOCAL_VIDEO:"选择本地视频设备",
	I18N_DIALOG_TIPMESSAGE_ALLOW_REMOTE_CTRL:"允许选择用户控制你的桌面",
	I18N_DIALOG_TIPMESSAGE_STOP_REMOTE_CTRL:"停止选择用户控制你的桌面",
	I18N_DIALOG_TIPMESSAGE_SENDFILE:"发送文件给选择用户",
	I18N_DIALOG_TIPMESSAGE_GETCALLBACK_PHONENUMBER:"填入号码，座席会回呼你"
}
LanguageString.English = {
	I18N_DIALOG_ConferenceMemberList:"Participant List",
    I18N_DIALOG_CurrentSelectedUser:"Current Selected User",
    I18N_DIALOG_LOCAL_VIDEO_DEVICE_LIST:"Local Video Device List",
    I18N_DIALOG_VIDEO_DEVICE_SELECTED:"Device Selected",
    I18N_DIALOG_CALLBACK_PHONENUMBER:"Callback Number",
	I18N_DIALOG_TIPMESSAGE_CHOOSE_LOCAL_VIDEO:"Select Local Video Device",
	I18N_DIALOG_TIPMESSAGE_ALLOW_REMOTE_CTRL:"Allow Selected User to Control Your Desktop",
	I18N_DIALOG_TIPMESSAGE_STOP_REMOTE_CTRL:"Disallow Selected User to Control Your Desktop",
	I18N_DIALOG_TIPMESSAGE_SENDFILE:"Send File to Selected User",
	I18N_DIALOG_TIPMESSAGE_GETCALLBACK_PHONENUMBER:"Leave your Number. We will call you back."
}