// main excute method
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var WndUiOcx = new WndUi();
var ICSClientOcx = new ICSClient();
var ConferenceOcx = new Conference();
var VoiceOcx = new Voice();
var AgentOcx = new Agent();
var Event = {};
var ConferenceNotPrintElems =
{
	SendMessage: [2],
	SendFile: [2],
	ReceiveFile: [2],
	JoinConf: [1]
};
var VoiceNotPrintElems =
{
	Call: [1],
	Register: [1, 2],
	DtmfDial: [1],
	SetSipTlsMode: [2],
	SetSipServerInfo: [1],
	SetLocalInfo: [1],
	AnonymousCall: [1, 2]
};
var ICSClientNotPrintElems = 
{
	Call: [2, 3],
	SendTextMsg: [2],
	SetServerInfo: [1]
};
var AgentNotPrintElems =
{
	Register: [1, 2],
	SignInEx: [2, 4],
	SendChat: [2],
	CallOutEx: [1, 2],
	TransOutEx2: [3],
	SetCallDataEx: [2],
	AgentSendDTMF: [1],
	ModifyAgentPwd: [1,2,3]
};
var ICSNotPrintJSONElems =
{
	SetServerInfo: ["ip"]
};

// !function whether object is null
function isNull(object)
{
	return (null===object || undefined===object);
}

// !function init
function initAgentApp(navigator, document, sLogDir)
{	      
	//Internationalization
	//I18N.utils.parseI18N(navigator,document,I18N.Module.AgentApp);
	//Initial log file
	FileUtil.setConfig({module:"AgentApp", logDir:sLogDir});
	WndUiOcx.init("WndUiOcx");
	ICSClientOcx.init("ICSClientOcx");
	ConferenceOcx.init("ConferenceOcx");
	VoiceOcx.init("VoiceOcx");
	AgentOcx.init("AgentOcx");
	LoadAgentConfig();
}

function initUserApp(navigator, document, sLogDir)
{
	//Internationalization
	//I18N.utils.parseI18N(navigator, document, I18N.Module.UserApp);
	//Initial log file
	FileUtil.setConfig({module:"UserApp", logDir:sLogDir});
	WndUiOcx.init("WndUiOcx");
	ICSClientOcx.init("ICSClientOcx");
	ConferenceOcx.init("ConferenceOcx");
	VoiceOcx.init("VoiceOcx");
	LoadUserConfig();
}

// !function print method's log of info level
function INFO_LOG_METHOD(component, logInfo)
{
    _appLog('[' + component + ']' + logInfo);
	try
	{
		FileUtil.writeLog(FileUtil.LogLevel.INFO,component,FileUtil.LogType.Function,logInfo);
	}
	catch (e)
	{
		//handle exception
	}
}

// !function print method's log of info level
function DEBUG_LOG_METHOD(component, logInfo) {
    _appLog('[' + component + ']' + logInfo);
    try {
        FileUtil.writeLog(FileUtil.LogLevel.DEBUG, component, FileUtil.LogType.Function, logInfo);
    }
    catch (e) {
        //handle exception
    }
}

// !function print method's log of info level
function WARN_LOG_METHOD(component, logInfo) {
    _appLog('[' + component + ']' + logInfo);
    try {
        FileUtil.writeLog(FileUtil.LogLevel.WARN, component, FileUtil.LogType.Function, logInfo);
    }
    catch (e) {
        //handle exception
    }
}

// !function print method's log of info level
function ERROR_LOG_METHOD(component, logInfo) {
    _appLog('[' + component + ']' + logInfo);
    try {
        FileUtil.writeLog(FileUtil.LogLevel.ERROR, component, FileUtil.LogType.Function, logInfo);
    }
    catch (e) {
        //handle exception
    }
}

//add '\n' in the JSON string.
function recoverJSONForm(objStr)
{
	objStr = objStr.replace("\{", "\{\n   ");
	objStr = objStr.replace("\}", "\n\}");
	objStr = objStr.replace(/\,/g, "\,\n   ");
	return objStr;
}

// !function WndUiOcx interfaces excute
function WndUiExcute(sInterfaceName)
{
	var _argumentsInfo = "";
	for(var i=0; i<arguments.length;++i)
	{
		_argumentsInfo += arguments[i]+",";
	}
	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("WndUiOcx", "Interface:"+sInterfaceName+ ", start.arguments:"+_argumentsInfo );
	
	if(isNull(sInterfaceName) )
	{
		alert("interface name is null.");
		return;
	}
	if("function" != typeof(WndUiOcx[sInterfaceName]) )
	{
		alert("it is not function.");
		return;
	}
	
	var _result = null;
	
	if(1 === arguments.length)
	{
		_result = WndUiOcx[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
		_result = WndUiOcx[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
		_result = WndUiOcx[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{
		_result = WndUiOcx[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
		_result = WndUiOcx[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
	
	INFO_LOG_METHOD("WndUiOcx", "Interface:"+sInterfaceName+",end.result:"+ _result);
	
	return _result;
}


// !function ICSClientOcx interfaces excute
function ICSClientExcute(sInterfaceName)
{
	var _argumentsInfo = "";
	for(var i=0; i<arguments.length;++i)
	{
		if(UTIL.isInArray(ICSClientNotPrintElems[sInterfaceName], i))
		{
			if(ICSNotPrintJSONElems[sInterfaceName])
			{
				var item = "";
				var items = ICSNotPrintJSONElems[sInterfaceName];
				var obj = JSON.parse(arguments[i]);
				for(var j=0; j<items.length;j++)
				{
					item = items[j];
					if("ip" == item){
						var nums = obj[item].split(".");
						obj[item] = "***.***." + nums[2] + "." + nums[3];
					}
					else
					{
						obj[item] = "******";
					}	
				}	
				_argumentsInfo += JSON.stringify(obj) + ",";
			}
			else
			{
				_argumentsInfo += "******" + ",";
			}
			continue;	
		}
		_argumentsInfo += arguments[i]+",";
	}
	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("ICSClientOcx", "Interface:"+sInterfaceName+ ", start.arguments:"+_argumentsInfo );
	
	if(isNull(sInterfaceName) )
	{
		alert("interface name is null.");
		return;
	}
	if("function" != typeof(ICSClientOcx[sInterfaceName]) )
	{
		alert("it is not function.");
		return;
	}
	
	var _result = null;
	
	if(1 === arguments.length)
	{
		_result = ICSClientOcx[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
		_result = ICSClientOcx[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
		_result = ICSClientOcx[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{
		_result = ICSClientOcx[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
		_result = ICSClientOcx[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
	
	INFO_LOG_METHOD("ICSClientOcx", "Interface:"+sInterfaceName+",end.result:"+ _result);
	
	return _result;
}


// !function AgentOcx interfaces excute
function AgentExcute(sInterfaceName)
{
	var _result = null;
	if (sInterfaceName == "ModifyAgentPwd")
	{	
		if (arguments[1] == arguments[2])
		{
			_result = "New password should different to old password";
			return _result;
		}
		if (arguments[2] != arguments[3])
		{
			_result = "Confirm password should equal to new password";
			return _result;
		}
		
	}
	
	
	var _argumentsInfo = "";
	var _phoneNumber = "";
	for(var i=0; i<arguments.length;++i)
	{	
		if(UTIL.isInArray(AgentNotPrintElems[sInterfaceName], i))
		{
			if((("Register" == sInterfaceName) || ("AgentSendDTMF" == sInterfaceName)) && (1 == i))
			{
				_phoneNumber = arguments[1].substr(arguments[1].length/2);
				_argumentsInfo += "***" + _phoneNumber + ",";
			}
			else if(("SignInEx" == sInterfaceName) && (4 == i))
			{
				_phoneNumber = arguments[4].substr(arguments[4].length/2);
				_argumentsInfo += "***" + _phoneNumber + ",";	
			}
			else if(("CallOutEx" == sInterfaceName) || ("TransOutEx2" == sInterfaceName))
			{
				_phoneNumber = arguments[i].substr(arguments[i].length/2);
				_argumentsInfo += "***" + _phoneNumber + ",";	
			}	
			else
			{
				_argumentsInfo += "******" + ",";
			}
			continue;
		}
		_argumentsInfo += arguments[i]+",";
	}

	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("AgentOcx", "Interface:"+sInterfaceName+ ", start.arguments:"+_argumentsInfo );
 
	if(isNull(sInterfaceName) )
	{
		alert("interface name is null.");
		return;
	}

	if("function" != typeof(AgentOcx[sInterfaceName]))
	{
		alert("it is not function.");
		return;
	}
	
	
	
	if(1 === arguments.length)
	{
		_result = AgentOcx[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
		_result = AgentOcx[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
		_result = AgentOcx[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{    
		_result = AgentOcx[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
		_result = AgentOcx[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
	
	INFO_LOG_METHOD("AgentOcx", "Interface:"+sInterfaceName+", end.result:"+ _result);
	
	return _result;
}

// !function ConferenceOcx interfaces excute
function ConferenceExcute(sInterfaceName)
{
	var _argumentsInfo = "";
	for(var i=0; i<arguments.length;++i)
	{
		if(UTIL.isInArray(ConferenceNotPrintElems[sInterfaceName], i))
		{
			_argumentsInfo += "******" + ",";
			continue;
		}
		_argumentsInfo += arguments[i]+",";
	}
	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("ConferenceOcx", "Interface:"+sInterfaceName+ ", start.arguments:"+_argumentsInfo );
	
	if(isNull(sInterfaceName) )
	{
		alert("interface name is null.");
		return;
	}
	if("function" != typeof(ConferenceOcx[sInterfaceName]) )
	{
		alert("it is not function.");
		return;
	}
	
	var _result = null;
	
	if(1 === arguments.length)
	{
		_result = ConferenceOcx[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
		_result = ConferenceOcx[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
		_result = ConferenceOcx[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{
		_result = ConferenceOcx[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
		_result = ConferenceOcx[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
	
	INFO_LOG_METHOD("ConferenceOcx", "Interface:"+sInterfaceName+",end.result:"+ _result);

	return _result;
}


// !function VoiceOCX interfaces excute
function VoiceExcute(sInterfaceName)
{
	var _argumentsInfo = "";
	var _nums = "";
	var _phoneNumber = "";
	for(var i=0; i<arguments.length;++i)
	{
		if(UTIL.isInArray(VoiceNotPrintElems[sInterfaceName], i))
		{
			if((("SetSipServerInfo" == sInterfaceName) || ("SetLocalInfo" == sInterfaceName)) && (1 == i))
			{
				_nums = arguments[1].split(".");
				_argumentsInfo += "***.***." + _nums[2] + "." + _nums[3] + ",";
			}
			else if((("Register" == sInterfaceName) || ("DtmfDial" == sInterfaceName) || ("Call" == sInterfaceName)) && (1 == i))
			{
				_phoneNumber = arguments[1].substr(arguments[1].length/2);
				_argumentsInfo += "***" + _phoneNumber + ",";
			}
			else if("AnonymousCall" == sInterfaceName)
			{
				_phoneNumber = arguments[i].substr(arguments[i].length/2);
				_argumentsInfo += "***" + _phoneNumber + ",";	
			}	
			else
			{
				_argumentsInfo += "******" + ",";
			}	
			continue;
		}
		_argumentsInfo += arguments[i]+",";
	}
	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("VoiceOcx", "Interface:"+sInterfaceName+ ", start.arguments:"+_argumentsInfo );
	
	if(isNull(sInterfaceName) )
	{
		alert("interface name is null.");
		return;
	}
	if("function" != typeof(VoiceOcx[sInterfaceName]) )
	{
		alert("it is not function.");
	}
	
	var _result = null;
	
	if(1 === arguments.length)
	{
		_result = VoiceOcx[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
		_result = VoiceOcx[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
		_result = VoiceOcx[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{
		_result = VoiceOcx[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
		_result = VoiceOcx[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
	
	INFO_LOG_METHOD("VoiceOcx", "Interface:"+sInterfaceName+",end.result:"+ _result);
	
	return _result;
}


