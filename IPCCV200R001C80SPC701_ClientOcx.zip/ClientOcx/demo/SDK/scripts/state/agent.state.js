

//AgentStateClass define
function AgentStateClass() {
    this._WorkNo = 0;
	this._TalkFlag = 0;
	this._HoldFlag = 0;
	this._CallID = "4294967295-4294967295";
	this._Chat_CCBIdx = 0;
	this._CurrentCallCCBIdx = 1;
	this._MediaType = 5;
	this._CalleeNo = "";
	this._CalledNo = "";
	this._CallFeature = 0;
	this._ConfID = 0;
	this._ResultCode = 0;
	this._ParticipantType = 0;
	this._Participant = "";
	this._AgentChatList = [];

	this.GetWorkNo = function () {
	    return AgentOcx._ocx.WorkNo;
	}
	this.SetTalkFlag = function(usFlag)
	{
	    this._TalkFlag = usFlag;
	}

	this.GetTalkFlag = function () {
	    return this._TalkFlag;
	}

	this.SetHoldFlag =  function(usFlag)
	{
	    this._HoldFlag = parseInt(usFlag);
	}

	this.GetHoldFlag = function () {
	    return this._HoldFlag;
	}

	this.SetCallID =  function(sCallID)
	{
		this._CallID = sCallID;
    }

    this.GetCallID = function () {
        return this._CallID;
    }
	
	this.SetChatCCBIdx =  function(usCCBIdx)
	{
	    this._Chat_CCBIdx = usCCBIdx;
	}

	this.GetChatCCBIdx = function () {
	    return this._Chat_CCBIdx;
	}

	this.SetCurrentCallCCBIdx = function (usCCBIdx) {
	    this._CurrentCallCCBIdx = usCCBIdx;
        // when the first chat comes, select it 
	    if (this._CurrentCallCCBIdx === 1) {
	        this.SetChatCCBIdx(usCCBIdx);
	    }
	}

	this.GetCurrentCallCCBIdx = function () {
	    return this._CurrentCallCCBIdx;
	}

	this.SetMediaType =  function(usMediaType)
	{
	    this._MediaType = usMediaType;
	}

	this.GetMediaType = function () {
	    return this._MediaType;
	}

	this.SetCalleeNo =  function(sCalleeNo)
	{
	    this._CalleeNo = sCalleeNo;
	}

	this.GetCalleeNo = function () {
	    return this._CalleeNo;
	}
	
	this.SetCalledNo =  function(sCalledNo)
	{
	    this._CalledNo = sCalledNo;
	}

	this.GetCalledNo = function () {
	    return this._CalledNo;
	}
	this.SetCallFeature =  function(usCallFeature)
	{
	    this._CallFeature = usCallFeature;
	}

	this.GetCallFeature = function () {
	    return this._CallFeature;
	}

	this.SetConfID =  function(ulConfID)
	{
	    this._ConfID = ulConfID;
	}

	this.GetConfID = function () {
	    return this._ConfID;
	}

	this.SetResultCode = function(usResultCode)
	{
	    this._ResultCode = usResultCode;
	}

	this.GetResultCode = function () {
	    return this._ResultCode;
	}

	this.SetParticipantType =  function(usParticipantType)
	{
	    this._ParticipantType = usParticipantType;	
	}
	
    this.GetParticipantType = function () {
	    return this._ParticipantType;
	}

	this.SetParticipant =  function(sParticipant)
	{
	    this._Participant = sParticipant;
	}

    this.GetParticipant = function ()
	{
	    return this._Participant;
	}
	this.SetChatAnswered = function (ccbIdx) {
	    AgentUI.UpdateWhenChatAnswered(ccbIdx);
	    if (this._AgentChatList[ccbIdx - 1] === undefined || this._AgentChatList[ccbIdx - 1] === null) {
	        this._AgentChatList[ccbIdx - 1] = "";
	    }
	},
	this.ClearAgentChatContent = function (ccbIdx) {
	    if (this._AgentChatList[ccbIdx - 1] === null) {
	        return;
	    }
	    this._AgentChatList[ccbIdx - 1] = null;
	}
	this.AgentSendChatContent = function (ccbIdx, content) {
	    this._AgentChatList[ccbIdx - 1] += content + '\n';
	    AgentUI.UpdateWhenSendChatMessage(ccbIdx);
	}
	this.AgentReiceiveChatContent = function (ccbIdx, content) {
	    this._AgentChatList[ccbIdx - 1] += content + '\n';
	    AgentUI.UpdateWhenReceiveChatMessage(ccbIdx);
	}

	this.GetAgentChatContent = function (ccbIdx) {
	    return this._AgentChatList[ccbIdx - 1];
	}
}

//AgentStateClass methods define
AgentStateClass.prototype = {
    GetCallInfo: function () {
        var ret;

        ret = AgentOcx._ocx.QueryCallIDOnAgentEx(AgentOcx._ocx.WorkNo);

        if (ret !== 0) {
            return 1;
        }
        var callid = AgentOcx._ocx.GetCallIDByIdx(AgentOcx._ocx.CallIDNum - 1);
        if (callid === 0) {
            return 1;
        }

        ret = AgentOcx._ocx.QueryCallInfoEx(callid);

        if (ret === 0) {
            this.SetMediaType(AgentOcx._ocx.CallInfoEx_MediaType);
            this.SetCalleeNo(AgentOcx._ocx.CallInfoEx_Ani);
			this.SetCalledNo(AgentOcx._ocx.CallInfoEx_DialedNumber);
            this.SetCallFeature(AgentOcx._ocx.CallInfoEx_CallFeature);
        }
		//query the holdcall list to see if this call has been holded
		_return = AgentOcx._ocx.QueryHoldListEx();
		
        if (_return === 0) {
			this.SetHoldFlag(0);
            if (AgentOcx._ocx.CallIDNum > 0)
			{
				for (var i=0; i< AgentOcx._ocx.CallIDNum; i++){
					var tmpCallID = AgentOcx._ocx.GetCallIDByIdx(i);
					ret = AgentOcx._ocx.QueryCallInfoEx(tmpCallID);
					//if current callid equals tmpCallID, this call is holded
					if ((this.GetCalleeNo() === AgentOcx._ocx.CallInfoEx_Ani)  && (this.GetCalledNo() === AgentOcx._ocx.CallInfoEx_DialedNumber)){
						this.SetHoldFlag(1);
						break;
					}
				}
			}
			else {
				this.SetHoldFlag(0);
			}
			
        } else {
			this.SetHoldFlag(0);
		}
        return ret;
    }
}