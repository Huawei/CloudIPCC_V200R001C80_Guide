// ICSClient Ocx
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var ICSClient = function()
{
	this._ocx = null;; //ocx object
	
	// !function whether ocx is null(private function)
	this._isNull = function()
	{
		return (null==this._ocx || undefined==this._ocx);
	}
}

ICSClient.prototype = {
	// !function init ICSClient
	init: function(ocxId){
		this._ocx = document.getElementById(ocxId);
	},
	// !function Set icsgateway server info
	SetServerInfo: function(sServerInfo)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SetServerInfo(sServerInfo);
	},
	// !function Login icsgateway
	Login: function(sUserName)
	{
		if (this._isNull() ) 
		{
			return null;
		}

		var loginFlag = true;
		var ret = this._ocx.VerifyCert();
		if(ret != 0){
			loginFlag = confirm("当前登录存在安全风险，请确认是否继续登录");
		}
		if(loginFlag){
			var sslEnable = UserConfig.ICSClient["sslEnable"];
			if(!sslEnable){
				loginFlag = confirm("当前登录为非SSL方式，请确认是否继续登录");	
			}
		}

		if(loginFlag){
			return this._ocx.Login(sUserName);
		}
		return null;

	},
	// !function Logout icsgateway
	Logout: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.Logout();
	},
	// !function get verify code
	GetVerifyCode: function(imgId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		var result = "";
		var _verifyCodeInfo = this._ocx.GetVerifyCode();
		var _verifyCodeObj = eval("("+_verifyCodeInfo+")");
		if("0" == _verifyCodeObj.retcode)
		{
			result ="data:image/jpeg;base64," + _verifyCodeObj.result;
		}
		
		document.getElementById(imgId).src = result;
		
		return _verifyCodeObj.retcode;
	},
	// !function update verify code
	UpdateVerifyCode: function(sVerifyCode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.UpdateVerifyCode(sVerifyCode);
	},
	// !function create call
	Call: function(sMediaType, sAccessCode, sCallData, sUvid)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.Call(sMediaType, sAccessCode, sCallData, sUvid);
	},
	// !function release call
	Release: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.Release(sCallId);
	},
	// !function auto release all types of calls
	ReleaseAll: function()
	{
		var retAll = '';
		//if the webchat callid exists,release the corresponding callID
		if (ICSState.WebChatCallID !== '')
		{
			retAll = retAll + 'Release the webchat callID result:' + this._ocx.Release(ICSState.WebChatCallID);
		}
		//if the clickcall callid exists, release the corresponding callID
		if (ICSState.ClickCallCallID !== '')
		{
			retAll = retAll + 'Release the clickcall callID result:' + this._ocx.Release(ICSState.ClickCallCallID);
		}
		
		//if the callback callid exists, release the corresponding callID
		if (ICSState.CallbackCallID !== '')
		{
			retAll = retAll + 'Release the callback callID result:' + this._ocx.Release(ICSState.CallbackCallID);
		}
		return retAll;
	},
	// !function cancel queue
	CancelQueue: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.CancelQueue(sCallId);
	},
	// !function get queue info of the call
	GetQueueInfo: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetQueueInfo(sCallId);
	},
	// !function send Text message
	SendTextMsg: function(sCallId, sMessage)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SendTextMsg(sCallId, sMessage);
	},
	// !function get skill info with accesscodes
	GetSkillInfoByAccessCodes: function(sAccessCodes)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetSkillInfoByAccessCodes(sAccessCodes);
	},
	// !function get skill info with skillIds.skillIds,for example: [1,2,3]
	GetSkillInfosBySkillIds: function(sSkillIds)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetSkillInfosBySkillIds(sSkillIds);
	},
	// !function request meeting
	RequestMeeting: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.RequestMeeting(sCallId);
	},
	// !function reinvite agents of call to join meeting
	ReInviteMeeting: function(sConfId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.ReInviteMeeting(sConfId);
	},
	// !function terminate meeting
	TerminateMeeting: function(sConfId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.TerminateMeeting(sConfId);
	},
	// !function report the result of joining meeting
	ReportJoinMeetingResult: function(sConfId, sJoinSuccFlag, sResultCode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.ReportJoinMeetingResult(sConfId, sJoinSuccFlag, sResultCode);
	},
	// !function get the description of the result code
	GetResultDesc: function(sResultCode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetResultDesc(sResultCode);
	}
}