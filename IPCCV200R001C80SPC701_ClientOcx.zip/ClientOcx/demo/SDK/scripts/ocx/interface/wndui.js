// WndUi Ocx
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var WndUi = function()
{
	this._ocx = null;; //ocx object
	
	// !function whether ocx is null(private function)
	this._isNull = function()
	{
		return (null===this._ocx || undefined===this._ocx);
	}
}

WndUi.prototype = {
	// !function init wndui
	init: function(ocxId){
		this._ocx = document.getElementById(ocxId);
	},
	// !function create window
	Create: function(sTitle)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		var strResult = this._ocx.CreateWnd(sTitle);
		var obj = JSON.parse(strResult);
		if (parseInt(obj.resultCode) === 0)// if create window successfully, fill releated fields automatically
		{
			WndUIState.autoSetRelatedField(obj.hWnd);
		}
		return strResult;
	},
	// !function hide window
	Hide: function(sHWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.HideWnd(sHWnd);
	},
	// !function show window
	Show: function(sHWnd, sWidth, sHeight)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.ShowWnd(sHWnd, sWidth, sHeight);
	},
	// !function destroy window
	Destroy: function(sHWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.DestroyWnd(sHWnd);
	},
	// !function valid window
	IsValidWnd: function(sHWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.IsValidWnd(sHWnd);
	},
	// !function Get Windows info.
	GetWndsInfo: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetWndsInfo();
	}
}