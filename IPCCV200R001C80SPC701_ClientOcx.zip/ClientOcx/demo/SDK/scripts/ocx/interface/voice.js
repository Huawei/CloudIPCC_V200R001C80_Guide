// Voice Ocx
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var Voice = function()
{
	this._ocx = null;; //ocx object
	
	// !function whether ocx is null(private function)
	this._isNull = function()
	{
		return (null===this._ocx || undefined===this._ocx);
	}
}

Voice.prototype = {
	// !function init Voice
	init: function(ocxId){
		this._ocx = document.getElementById(ocxId);
	},
	//To:do add voice interfaces.
	SetSipServerInfo: function(sSipServerIp,sSipServerPort,sBackSipInfo)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetSipServerInfo(sSipServerIp,sSipServerPort,sBackSipInfo);
	},
	SetLocalInfo: function(sLocalIp,sLocalSipPort,sLocalAudioPort)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetLocalInfo(sLocalIp,sLocalSipPort,sLocalAudioPort);
	},
	SetConfig: function(cfgKey,cfgValue)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetConfig(cfgKey,cfgValue);
	},
	Register: function(sTelePhoneNumber,sPassword,sRegisterMode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.Register(sTelePhoneNumber,sPassword,sRegisterMode);
	},
	AutoRegister: function(btnSetServerInfo, btnSetLocalInfo, btnRegister)
	{
		document.getElementById(btnSetServerInfo).click();
		document.getElementById(btnSetLocalInfo).click();
		document.getElementById(btnRegister).click();
	},

	GetConfig: function(sCfgKey)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.GetConfig(sCfgKey);
	},
	Deregister: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.Deregister();
	},
	Call: function(sCalleeNumber)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.Call(sCalleeNumber);
	},
	AnonymousCall: function(sAnonymousNumber,sCalleeNumber)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.AnonymousCall(sAnonymousNumber,sCalleeNumber);
	},
	Answer: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.Answer(sCallId);
	},
	Release: function(sCallId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.Release(sCallId);
	},
	DtmfDial: function(sDialNumber)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.DtmfDial(sDialNumber);
	},
	SendSipInfo: function(sSipInfo)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SendSipInfo(sSipInfo);
	},
	SetAudioRtpType: function(sAudioRtpType)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetAudioRtpType(sAudioRtpType);
	},
	SetSipTlsMode: function(sSipTransportMode,sCertFilePath)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetSipTlsMode(sSipTransportMode,sCertFilePath);
	},
	SetVolume: function(sInputType,sVolume)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetVolume(sInputType,sVolume);
	},
	GetVolume: function(sInputType)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.GetVolume(sInputType);
	},
	SetDeviceIndex: function(sInputType,sMicIndex)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetVolume(sInputType,sMicIndex);
	},
	GetDevices: function(sInputType)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.GetDevices(sInputType);
	},
	GetResultDesc: function(sResultCode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.GetResultDesc(sResultCode);
	}
}