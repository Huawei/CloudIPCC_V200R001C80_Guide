// Conference Ocx Event Handle
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

WndUIState = {
	//Althought this funciton is empty , but do not remove it.It will be invoked by wndui.js, but we do not need to set any field.
	autoSetRelatedField: function(hwnd)
	{
		
	}
}

Event.WndUIOcx = {
	WndUiInitResultEvent: function(sEventInfo)
	{
	}
}
