var ChildRet;
function OpenDialog(sOprType){
	var arg = new Object();
	arg.win = window;
	arg.str = sOprType;
	var ret = window.showModalDialog("scripts/common/agentdialog.html",arg,"dialogWidth=320px;dialogHeight=240px;status=yes;help=no;");
	return ret;
}

function OpenCallOutDialog()
{
	return OpenDialog('CallOut');
}

function OpenInnerCallDialog()
{
	return OpenDialog('InnerCall');
}

function OpenDTMFDialog()
{
	return OpenDialog('DTMF');
}

function OpenCallDataDialog()
{
	return OpenDialog('CallData');
}

function OpenTransferDialog()
{
	return OpenDialog('Transfer');
}

function OpenInnerHelpDialog()
{
	return OpenDialog('InnerHelp');
}

function OpenBusyDialog()
{
	return OpenDialog('BusyWithReason');
}

function OpenMultiConfDialog()
{
	return OpenDialog('MultiConf');
}

function OpenModifyPWDDialog()
{
	return OpenDialog('ModifyPWD');
}